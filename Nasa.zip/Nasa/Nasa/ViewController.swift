//
//  ViewController.swift
//  Nasa
//
//  Created by Johnne Lemand on 26/12/23.
//

import UIKit

class ViewController: UIViewController {

    
    var ListPhotosLiked: [Photo] = []
    
    var nasaManager = NasaManager()
    
    var nasaMostrar: Photo?
    
    @IBOutlet weak var tableNasaPhotos: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nasaManager.delegado = self
        tableNasaPhotos.delegate = self
        tableNasaPhotos.dataSource = self
        
        nasaManager.obtainListsNasa()
        
    }


}

extension ViewController: NasaManagerDelegate {
    func mostrarError(cualError: String) {
        
    }
    
    func mostrarFotos(listaFotos: [Photo]) {
        
        self.ListPhotosLiked = listaFotos
        DispatchQueue.main.async {
            self.tableNasaPhotos.reloadData()
            
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ListPhotosLiked.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = ListPhotosLiked[indexPath.row].earthDate
        return cell
    }
    
    
}

