//
//  NasaPhotos.swift
//  Nasa
//
//  Created by Johnne Lemand on 26/12/23.
//

//import Foundation
//
//protocol ServiceApi{
//    func callService(completion: @escaping (Result<NasaData, Error>) -> Void)
//}
//
//class NasaPhotos: ServiceApi{
//
//    func callService(completion: @escaping (Result<NasaData, Error>) -> Void) {
//        let session = URLSession.shared
//
//        let url = URL(string: "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?api_key=ebIStTbKmXzyVhtxkCOpqLeNX616o5Ry9lcthjQx&sol=2000&page=1")!
//        let dataTask = session.dataTask(with: URLRequest(url: url)) {data, response, error in
//            DispatchQueue.main.async {
//                if let error = error{
//                    completion(.failure(error))
//                }else if let data = data {
//                    do{
//                        let nasaObject = try JSONDecoder().decode(NasaData.self, from: data)
//                        completion(.success(nasaObject))
//                    }catch{
//                        completion(.failure(error))
//                    }
//                }
//            }
//        }
//        dataTask.resume()
//    }
//}
import Foundation

protocol NasaManagerDelegate{
    
    
    func mostrarFotos(listaFotos: [Photo])
    func mostrarError (cualError: String)
    
}


    
    struct NasaManager {
        var delegado: NasaManagerDelegate?
        
        let nasaURL = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?api_key=ebIStTbKmXzyVhtxkCOpqLeNX616o5Ry9lcthjQx&sol=2000&page=1"
        
        
        
        
        
        func obtainListsNasa(){
            
            if let url = URL(string: nasaURL){
                let session = URLSession(configuration: .default)
                
                let dataTask = session.dataTask(with: url) { data, response, error in
                    if let e = error {
                        print("error en el servidor: \(e.localizedDescription)")
                    }
                    ///DATA
                    if let datosSeguros = data {
                        //Decodificamos la data segura
                        let decoder = JSONDecoder()
                        
                        do{
                            let dataDecodificada = try
                            decoder.decode([Photo].self, from: datosSeguros)
                            
                            
                            
                            
                            //Mandamos la lista de objetos al vc a traves del delegate
                            delegado?.mostrarFotos(listaFotos: dataDecodificada)
                            
                        }catch{
                            print("Debug: error al decodificar \(error.localizedDescription)")
                            delegado?.mostrarError(cualError: "error al decodificar \(error.localizedDescription)")
                        }
                        
                    }
                }
                
                dataTask.resume()
            }
        }
        
    }
